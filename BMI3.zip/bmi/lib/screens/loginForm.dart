import 'package:flutter/material.dart';

class LOGINPAGE extends StatefulWidget {
  const LOGINPAGE({super.key});

  @override
  State<LOGINPAGE> createState() => _LOGINPAGEState();
}

class _LOGINPAGEState extends State<LOGINPAGE> {
  TextEditingController textfield = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea
    ( 
      child: Scaffold(
        body: 
        Column(
        children: [
          //SizedBox(width:200),
          TextField(
                    controller: textfield,
                    //obscureText: true,
                    //obscuringCharacter: "%",
                    //style: ,
                    decoration: const InputDecoration(
                      border: const OutlineInputBorder(
                        
                        borderRadius: BorderRadius.all(Radius.circular(20)),
                      ),
                      prefixIcon: Icon(Icons.search),
                      suffixIcon: Icon(Icons.clear),
                      label: Text("username"),),
                    keyboardType: TextInputType.number,
                    onChanged: (string){
                     // print(textfeild.text); //controller --> text
                      print("This is the text from $string");
                    },
                    onEditingComplete: () {
                      print("this is the final submission from the textfield ${textfield.text}");
                    },
                  ),
                  SizedBox(height:20),
                  TextField(
                    controller: textfield,
                    //obscureText: true,
                    //obscuringCharacter: "%",
                    //style: ,
                    decoration: const InputDecoration(
                      border: const OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(20)),
                      ),
                      prefixIcon: Icon(Icons.search),
                      suffixIcon: Icon(Icons.clear),
                      label: Text("PASSWORD"), hintText: "min 8 characters"),
                    keyboardType: TextInputType.number,
                    onChanged: (string){
                     // print(textfeild.text); //controller --> text
                      print("This is the text from $string");
                    },
                    onEditingComplete: () {
                      print("this is the final submission from the textfield ${textfield.text}");
                    },
                  ),
                  
        ],
          ),
      ));
  }
}